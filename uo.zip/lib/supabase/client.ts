import { createBrowserClient } from "@supabase/ssr"

let client: ReturnType<typeof createBrowserClient> | null = null

export function getSupabaseBrowserClient() {
  if (client) {
    return client
  }

  client = createBrowserClient("https://hymgahzujbxsxcmpctfv.supabase.co", 
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh5bWdhaHp1amJ4c3hjbXBjdGZ2Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2NzQxODgxNywiZXhwIjoyMDgyOTk0ODE3fQ.oog_zFOFlQ6CaTQaEJVIo6nSVD7ngWdYHkdQTycL9lA")

  return client
}
